# FarmGamesProject

FarmGamesProject is a Telegram-based game launcher that allows you to easily select and play games directly from a
simple GUI interface.

## Project Structure

- `games/`
    - Each directory corresponds to a specific game and is named after the game's `bot_id`.
    - Each game directory contains:
        - `assets/` - Contains images and other resources specific to the game.
        - `config.json` - The configuration file for the game.
        - `strategy.py` - The script that defines the game's strategy logic.

- `logs/`
    - Stores log files generated during the execution of the project.

- `modules/`
    - Contains utility modules and the Telegram launcher logic.
    - `config_manager.py` - Handles loading and parsing of configuration files.
    - `image_processing.py` - Provides utilities for image recognition and processing.
    - `logger_config.py` - Configuration for logging across the project.
    - `telegram_launcher.py` - Manages launching the Telegram application.

- `start_menu/`
    - Contains the code for the graphical interface where users select games to play.
    - `start_menu.py` - Main script to create and handle the start menu GUI.

- `tests/`
    - Contains test scripts for various components of the project.

- `main.py`
    - The main entry point of the FarmGamesProject. It initializes the logger, loads all game configurations, displays
      the start menu for game selection, and launches the selected games.

- `requirements.txt`
    - A list of dependencies required for the project.

## Getting Started

### Prerequisites

- Python 3.12 or higher
- Tkinter library (usually included with Python installations)
- Telegram Desktop application installed on your computer

### Installation

1. Clone this repository to your local machine:

    ```bash
    git clone https://github.com/yourusername/FarmGamesProject.git
    cd FarmGamesProject
    ```

2. Install the required Python packages:

    ```bash
    pip install -r requirements.txt
    ```

### Usage

1. Run the project by executing the following command:

    ```bash
    python main.py
    ```

2. A graphical interface will open, allowing you to select which games you want to play.

3. After selecting the games, press the "Start" button to launch the selected games. The games will be launched through
   Telegram, and the strategies for each game will be executed according to the defined logic.

### Project Configuration

Each game's configuration is stored in its respective directory under `games/<bot_id>/config.json`. These configurations
are loaded automatically when the game is launched.

### Logging

Logs are stored in the `logs/` directory. You can review the logs to debug any issues or monitor the project's activity.

### Contributing

This project is currently being developed privately, and contributions are managed by the project owner and team. Feel
free to fork this repository for your own use.

### License

This project is licensed under the MIT License. See the `LICENSE` file for more details.
